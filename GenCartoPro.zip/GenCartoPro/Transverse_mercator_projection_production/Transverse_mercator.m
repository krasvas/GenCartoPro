%     GenCartoPro: GENeration of CARTOgraphic PROjections
%     Copyright (C) 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography
% 
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
%     For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr 
clear all
close all
clc
format long g

%--------------------------------------------------------------------------
%Required inputs for the execution of the source code
%--------------------------------------------------------------------------
spacing=30; %grid spacing in degs (this value corresponds to the grid cell size)
R=6371000; %earth's radius in meters(m)
scale=0.5*10^6; %scale factor to plot ellipses
%--------------------------------------------------------------------------
% Grid generation according to the predefined spacing value (cell size)
%--------------------------------------------------------------------------
%f:phi (degs)
f=[0:spacing:90];
f=f*(pi/180);%phi (rads)
n_f=length(f); %number of grid rows

%l:lamda in degs
l=[-90:spacing:90];
l=l*(pi/180);%lamda in rads
n_l=length(l); %number of grid columns
n=n_f*n_l; %number of grid points

%generate the grid
grid=zeros(n_l*n_f,2); %all (f,l) combinations
k=1;%counter
for i=1:n_f
    for j=1:n_l
    grid(k,1)=f(i);
    grid(k,2)=l(j);
    k=k+1;
    end
end
%all phi and lamda values in the generated grid (in rads)
f=grid(:,1);
l=grid(:,2);

%f,l to u,v
u=atan(1./(cot(f).*cos(l)));
v=asin(cos(f).*sin(l));

%Transverse Mercator Projection (variable: EMP)
x=R*log(tan((pi/4)+(v/2)));
y=R*u;
mm=1./cos(v);
mp=mm;
EMP=[f*180/pi l*180/pi f l x y u v mp mm];

%remove records  v=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n
    if EMP(i,8)~=0 
        EMP_n0(p_n0,:)=EMP(i,:);
        p_n0=p_n0+1;        
    end
end
%remove records for l=+-180
p_n0_l180=1; %pointer
n0=size(EMP_n0);
n0=n0(1,1);
for i=1:n0
    if EMP_n0(i,2)~=180 && EMP_n0(i,2)~=-180
        EMP_n0_l180(p_n0_l180,:)=EMP_n0(i,:);
        p_n0_l180=p_n0_l180+1;        
    end
end
%%%
p_n0_l180_0_90=1; %pointer
n0_l180=size(EMP_n0_l180);
n0_l180=n0_l180(1,1);
for i=1:n0_l180
    if EMP_n0_l180(i,10)<2
        EMP_n0_l180_0_90(p_n0_l180_0_90,:)=EMP_n0_l180(i,:);
        p_n0_l180_0_90=p_n0_l180_0_90+1;        
    end
end

%%%

figure 
ellipse_on_projection(EMP_n0_l180_0_90(:,5),EMP_n0_l180_0_90(:,6),EMP_n0_l180_0_90(:,9),EMP_n0_l180_0_90(:,10),scale)
%ellipse_on_projection(EIP(:,5),EIP(:,6),EIP(:,9),EIP(:,10),scale)

%hold on
%plot(x,y,'r+');
axis equal
axis off
title('Transverse Mercator Projection','Fontsize',15)


%compute move
f_move=pi/2;
l_move=0;
u_move=atan(1./(cot(f_move).*cos(l_move)));
v_move=asin(cos(f_move).*sin(l_move));
y_move=R*u_move;
kappa=y_move;


%f:phi (degs)
f=[-90:spacing:0];
f=f*(pi/180);%phi (rads)
n_f=length(f); %number of grid rows

%l:lamda in degs
l=[-90:spacing:90];
l=l*(pi/180);%lamda in rads
n_l=length(l); %number of grid columns
n=n_f*n_l; %number of grid points

%generate the grid
grid=zeros(n_l*n_f,2); %all (f,l) combinations
k=1;%counter
for i=1:n_f
    for j=1:n_l
    grid(k,1)=f(i);
    grid(k,2)=l(j);
    k=k+1;
    end
end
%all phi and lamda values in the generated grid (in rads)
f=grid(:,1);
l=grid(:,2);

%f,l to u,v
u=atan(1./(cot(f).*cos(l)));
v=asin(cos(f).*sin(l));

%Transverse Mercator Projection (variable: EMP)
x=R*log(tan((pi/4)+(v/2)));
y=R*u;
mm=1./cos(v);
mp=mm;
EMP=[f*180/pi l*180/pi f l x y u v mp mm];

%remove records  v=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n
    if EMP(i,8)~=0 
        EMP_n0(p_n0,:)=EMP(i,:);
        p_n0=p_n0+1;        
    end
end
%remove records for l=+-180
p_n0_l180=1; %pointer
n0=size(EMP_n0);
n0=n0(1,1);
for i=1:n0
    if EMP_n0(i,2)~=180 && EMP_n0(i,2)~=-180
        EMP_n0_l180(p_n0_l180,:)=EMP_n0(i,:);
        p_n0_l180=p_n0_l180+1;        
    end
end
%%%
p_n0_l180_0_90=1; %pointer
n0_l180=size(EMP_n0_l180);
n0_l180=n0_l180(1,1);
for i=1:n0_l180
    if EMP_n0_l180(i,10)<2
        EMP_n0_l180_0_90(p_n0_l180_0_90,:)=EMP_n0_l180(i,:);
        p_n0_l180_0_90=p_n0_l180_0_90+1;        
    end
end

%%%

 
hold on

ellipse_on_projection(EMP_n0_l180_0_90(:,5),EMP_n0_l180_0_90(:,6),EMP_n0_l180_0_90(:,9),EMP_n0_l180_0_90(:,10),scale)
%ellipse_on_projection(EIP_n0_l180(:,5),EIP_n0_l180(:,6),EIP_n0_l180(:,9),EIP_n0_l180(:,10),scale)
%hold on
%plot(x,y,'r+');
axis equal
axis off
title('Transverse Mercator Projection','Fontsize',15)



%f:phi (degs)
f=[0:spacing:90];
f=f*(pi/180);%phi (rads)
n_f=length(f); %number of grid rows

%l:lamda in degs
l=[-90:spacing:90];
l=l*(pi/180);%lamda in rads
n_l=length(l); %number of grid columns
n=n_f*n_l; %number of grid points

%generate the grid
grid=zeros(n_l*n_f,2); %all (f,l) combinations
k=1;%counter
for i=1:n_f
    for j=1:n_l
    grid(k,1)=f(i);
    grid(k,2)=l(j);
    k=k+1;
    end
end
%all phi and lamda values in the generated grid (in rads)
f=grid(:,1);
l=grid(:,2);

%f,l to u,v
u=atan(1./(cot(f).*cos(l)));
v=asin(cos(f).*sin(l));

%Transverse Mercator Projection (variable: EMP)
x=R*log(tan((pi/4)+(v/2)));
y=R*u;
mm=1./cos(v);
mp=mm;
EMP=[f*180/pi l*180/pi f l x y u v mp mm];

%remove records  v=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n
    if EMP(i,8)~=0 
        EMP_n0(p_n0,:)=EMP(i,:);
        p_n0=p_n0+1;        
    end
end
%remove records for l=+-180
p_n0_l180=1; %pointer
n0=size(EMP_n0);
n0=n0(1,1);
for i=1:n0
    if EMP_n0(i,2)~=180 && EMP_n0(i,2)~=-180
        EMP_n0_l180(p_n0_l180,:)=EMP_n0(i,:);
        p_n0_l180=p_n0_l180+1;        
    end
end
%%%
p_n0_l180_0_90=1; %pointer
n0_l180=size(EMP_n0_l180);
n0_l180=n0_l180(1,1);
for i=1:n0_l180
    if EMP_n0_l180(i,10)<2
        EMP_n0_l180_0_90(p_n0_l180_0_90,:)=EMP_n0_l180(i,:);
        p_n0_l180_0_90=p_n0_l180_0_90+1;        
    end
end

%%%

hold on
ellipse_on_projection(EMP_n0_l180_0_90(:,5),2*kappa-EMP_n0_l180_0_90(:,6),EMP_n0_l180_0_90(:,9),EMP_n0_l180_0_90(:,10),scale)
%ellipse_on_projection(EIP_n0_l180(:,5),EIP_n0_l180(:,6),EIP_n0_l180(:,9),EIP_n0_l180(:,10),scale)
%hold on
%plot(x,y,'r+');
axis equal
axis off
title('Transverse Mercator Projection','Fontsize',15)


%f:phi (degs)
f=[-90:spacing:0];
f=f*(pi/180);%phi (rads)
n_f=length(f); %number of grid rows

%l:lamda in degs
l=[-90:spacing:90];
l=l*(pi/180);%lamda in rads
n_l=length(l); %number of grid columns
n=n_f*n_l; %number of grid points

%generate the grid
grid=zeros(n_l*n_f,2); %all (f,l) combinations
k=1;%counter
for i=1:n_f
    for j=1:n_l
    grid(k,1)=f(i);
    grid(k,2)=l(j);
    k=k+1;
    end
end
%all phi and lamda values in the generated grid (in rads)
f=grid(:,1);
l=grid(:,2);

%f,l to u,v
u=atan(1./(cot(f).*cos(l)));
v=asin(cos(f).*sin(l));

%Transverse Mercator Projection (variable: EMP)
x=R*log(tan((pi/4)+(v/2)));
y=R*u;
mm=1./cos(v);
mp=mm;
EMP=[f*180/pi l*180/pi f l x y u v mp mm];

%remove records  v=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n
    if EMP(i,8)~=0 
        EMP_n0(p_n0,:)=EMP(i,:);
        p_n0=p_n0+1;        
    end
end
%remove records for l=+-180
p_n0_l180=1; %pointer
n0=size(EMP_n0);
n0=n0(1,1);
for i=1:n0
    if EMP_n0(i,2)~=180 && EMP_n0(i,2)~=-180
        EMP_n0_l180(p_n0_l180,:)=EMP_n0(i,:);
        p_n0_l180=p_n0_l180+1;        
    end
end
%%%
p_n0_l180_0_90=1; %pointer
n0_l180=size(EMP_n0_l180);
n0_l180=n0_l180(1,1);
for i=1:n0_l180
    if EMP_n0_l180(i,10)<2
        EMP_n0_l180_0_90(p_n0_l180_0_90,:)=EMP_n0_l180(i,:);
        p_n0_l180_0_90=p_n0_l180_0_90+1;        
    end
end

%%%

hold on
ellipse_on_projection(EMP_n0_l180_0_90(:,5),2*kappa-EMP_n0_l180_0_90(:,6),EMP_n0_l180_0_90(:,9),EMP_n0_l180_0_90(:,10),scale)
%ellipse_on_projection(EIP_n0_l180(:,5),EIP_n0_l180(:,6),EIP_n0_l180(:,9),EIP_n0_l180(:,10),scale)
%hold on
%plot(x,y,'r+');
axis equal
axis off
title('Transverse Mercator Projection','Fontsize',15)


%--------------------------------------------------------------------------
% Import coastline points
%--------------------------------------------------------------------------
coastline=load('world_coastline_demo.txt');
id=coastline(:,1);
l=coastline(:,2)*(pi/180);%(rads)
f=coastline(:,3)*(pi/180);%(rads)
% max(l)
% min(l)
% max(f)
% min(f)

n=size(id);
n=n(1,1);
% 
% for i=1:n
% 
%     if l(i)>pi/2 || l(i)<-pi/2
%         l(i)=180-l(i);
%     end
%         
% end


coastline_part1=[];
for i=1:n
    if f(i)>0 && f(i)<pi/2 && l(i)>-pi/2 && l(i)<pi/2 
        coastline_part1=[coastline_part1; coastline(i,:)];
    end
end

coastline_part2=[];
for i=1:n
    if f(i)<0 && f(i)>-pi/2 && l(i)>-pi/2 && l(i)<pi/2 
        coastline_part2=[coastline_part2; coastline(i,:)];
    end
end

coastline_part3=[];
for i=1:n
    if (f(i)>0 && f(i)<pi/2 && l(i)>-pi && l(i)<-pi/2) || (f(i)>0 && f(i)<pi/2 && l(i)>pi/2 && l(i)<pi)
        coastline_part3=[coastline_part3; coastline(i,:)];
    end
end

coastline_part4=[];
for i=1:n
    if (f(i)<0 && f(i)>-pi/2 && l(i)>-pi && l(i)<-pi/2) || (f(i)<0 && f(i)>-pi/2 && l(i)>pi/2 && l(i)<pi)
        coastline_part4=[coastline_part4; coastline(i,:)];
    end
end
%number of points in part 1
n_1=size(coastline_part1);
n_1=n_1(1,1);

%number of points in part 2
n_2=size(coastline_part2);
n_2=n_2(1,1);


%number of points in part 3
n_3=size(coastline_part3);
n_3=n_3(1,1);
%number of points in part 4
n_4=size(coastline_part4);
n_4=n_4(1,1);

first_id_1=coastline_part1(1,1); %IDs must be started from number one in order to use plot_coastline function
first_id_2=coastline_part2(1,1); %IDs must be started from number one in order to use plot_coastline function
first_id_3=coastline_part3(1,1); %IDs must be started from number one in order to use plot_coastline function
first_id_4=coastline_part4(1,1); %IDs must be started from number one in order to use plot_coastline function

if first_id_1>1    
    for i=1:n_1
        coastline_part1(i,1)=coastline_part1(i,1)-(first_id_1-1);
    end  
end
if first_id_2>1    
    for i=1:n_2
        coastline_part2(i,1)=coastline_part2(i,1)-(first_id_2-1);
    end  
end
if first_id_3>1    
    for i=1:n_3
        coastline_part3(i,1)=coastline_part3(i,1)-(first_id_3-1);
    end  
end
if first_id_4>1    
    for i=1:n_4
        coastline_part4(i,1)=coastline_part4(i,1)-(first_id_4-1);
    end  
end

%part 1
id_1=coastline_part1(:,1);
l_1=coastline_part1(:,2)*(pi/180);%(rads)
f_1=coastline_part1(:,3)*(pi/180);%(rads)

%part 2
id_2=coastline_part2(:,1);
l_2=coastline_part2(:,2)*(pi/180);%(rads)
f_2=coastline_part2(:,3)*(pi/180);%(rads)

%part 3
id_3=coastline_part3(:,1);
l_3=coastline_part3(:,2)*(pi/180);%(rads)
l_3=pi-l_3;
f_3=coastline_part3(:,3)*(pi/180);%(rads)
%part 4
id_4=coastline_part4(:,1);
l_4=coastline_part4(:,2)*(pi/180);%(rads)
l_4=pi-l_4;
f_4=coastline_part4(:,3)*(pi/180);%(rads)

u_1=atan(1./(cot(f_1).*cos(l_1)));
v_1=asin(cos(f_1).*sin(l_1));
x_1=R*log(tan((pi/4)+(v_1/2)));
y_1=R*u_1;
plot_coastline([id_1 x_1 y_1])

hold on
u_2=atan(1./(cot(f_2).*cos(l_2)));
v_2=asin(cos(f_2).*sin(l_2));
x_2=R*log(tan((pi/4)+(v_2/2)));
y_2=R*u_2;
plot_coastline([id_2 x_2 y_2])

hold on
u_3=atan(1./(cot(f_3).*cos(l_3)));
v_3=asin(cos(f_3).*sin(l_3));
x_3=R*log(tan((pi/4)+(v_3/2)));
y_3=R*u_3;
plot_coastline([id_3 x_3 2*kappa-y_3])

hold on
u_4=atan(1./(cot(f_4).*cos(l_4)));
v_4=asin(cos(f_4).*sin(l_4));
x_4=R*log(tan((pi/4)+(v_4/2)));
y_4=R*u_4;
plot_coastline([id_4 x_4 2*kappa-y_4])

saveas(gcf,'Transverse Mercator Projection.pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('End of results\n\n\n\n\n')

fprintf('\n GenCartoPro: GENeration of CARTOgraphic PROjections \n')
fprintf(' 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography \n')
fprintf('\n')
fprintf(' This program is free software: you can redistribute it and/or modify\n')
fprintf(' it under the terms of the GNU General Public License as published by\n')
fprintf(' the Free Software Foundation, either version 3 of the License, or\n')
fprintf(' (at your option) any later version.\n')
fprintf('\n')
fprintf(' This program is distributed in the hope that it will be useful,\n')
fprintf(' but WITHOUT ANY WARRANTY; without even the implied warranty of\n')
fprintf(' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n')
fprintf(' GNU General Public License for more details.\n')
fprintf('\n')
fprintf(' You should have received a copy of the GNU General Public License\n')
fprintf(' along with this program.  If not, see <http://www.gnu.org/licenses/>.\n')
fprintf('\n')
fprintf(' For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr\n')