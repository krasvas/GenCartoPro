%     GenCartoPro: GENeration of CARTOgraphic PROjections
%     Copyright (C) 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography
% 
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
%     For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr 

function projection_plot=ellipse_on_projection(x,y,mm,mp,scale,scale_ellipse)
n=length(x);

for i=1:n
    ellipse_plot(scale*x(i),scale*y(i),scale_ellipse*mm(i),scale_ellipse*mp(i))
    hold on
end

end
