GenCartoPro: GENeration of CARTOgraphic PROjections

GenCartoPro is a MATLAB toolbox appropriate for the production of cartographic projections based on the generation of a rectangle grid with predefined cell size.
Additionally, GenCartoPro supports the performance of cartographic projections using datasets referred to coastline spatial data. A demo file with world coastline dataset is provided for the execution of the corresponded m-file (source of world coastline data: http://www.naturalearthdata.com/downloads/, the provided dataset has been modified in order to be adapted in GenCartoPro).  

The source code of GenCartoPro is distributed under the 3rd version of GNU General Public License as published by the Free Software Foundation (GPLv3).
You can receive a copy of the GNU General Public License by the file LICENSE.txt. 

GenCartoPro has been produced for the needs of Kallipos Project and specifically for the ebook of Analytical Cartography (Nakos, 2015).
For further information, please send an email to: <krasanakisv@gmail.com> or <krasvas@mail.ntua.gr>

Please cite the work below as reference to GenCartoPro:
Krassanakis V., Mitropoulos V., & Nakos B. (2016), GenCartoPro: A new toolbox for map projections production for the support of cartographic education (In Greek), Proceedings of 14th National Cartographic Conference of the Hellenic Cartographic Society, 2-4 November, Thessaloniki.
