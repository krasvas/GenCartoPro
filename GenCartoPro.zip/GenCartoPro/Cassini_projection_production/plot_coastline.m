%     GenCartoPro: GENeration of CARTOgraphic PROjections
%     Copyright (C) 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography
% 
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
%     For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr 

function plot_coastline_plots=plot_coastline(coastline)

id=coastline(:,1);
x=coastline(:,2);
y=coastline(:,3);
n=size(coastline);
n=n(1,1); %number of points

k=1;
d=[];
for i=1:n
    if k==id(i)
        d=[d;x(i) y(i)];
    else
        plot(d(:,1),d(:,2));
        hold on
        d=[x(i) y(i)];
        k=k+1;
    end
end
hold on
plot(d(:,1),d(:,2));
axis equal
axis off
end



