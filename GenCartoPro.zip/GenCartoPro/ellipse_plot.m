%     GenCartoPro: GENeration of CARTOgraphic PROjections
%     Copyright (C) 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography
% 
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
%     For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr  

function ellipse=ellipse_plot(xc,yc,m1,m2)

m1=abs(m1);
m2=abs(m2);

t=[0:pi/100:2*pi];
x=xc+m1*cos(t);
y=yc+m2*sin(t);
plot(x,y)
hold on
plot(xc,yc,'k.')
axis equal
axis off
end
