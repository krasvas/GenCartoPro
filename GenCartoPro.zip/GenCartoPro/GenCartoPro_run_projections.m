%     GenCartoPro: GENeration of CARTOgraphic PROjections
%     Copyright (C) 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography
% 
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
%     For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr 


%History & command window initialization
clear all
close all
clc
format long g

%--------------------------------------------------------------------------
% Import coastline points
%--------------------------------------------------------------------------
coastline=load('world_coastline_demo.txt');
id_coastline=coastline(:,1);
l_coastline=coastline(:,2)*(pi/180);%(rads)
f_coastline=coastline(:,3)*(pi/180);%(rads)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Seperate north and south part of the coastline (north part after 20
%degrees)
n=size(id_coastline);
n=n(1,1);
coastline_north_part=[];
coastline_south_part=[];
for i=1:n
    if f_coastline(i)>(pi/9) %|| f(i)==0 %select the north part after removing the first 20 degrees(pi/9 rads) 
        coastline_north_part=[coastline_north_part; coastline(i,:)];
    else
        coastline_south_part=[coastline_south_part; coastline(i,:)];
    end
end
%number of point in north part
n_north=size(coastline_north_part);
n_north=n_north(1,1);
%number of point in south part
n_south=size(coastline_south_part);
n_south=n_south(1,1);
first_id_north=coastline_north_part(1,1); %IDs must be started from number one in order to use plot_coastline function
first_id_south=coastline_south_part(1,1); %IDs must be started from number one in order to use plot_coastline function

if first_id_north>1    
    for i=1:n_north
        coastline_north_part(i,1)=coastline_north_part(i,1)-(first_id_north-1);
    end
else
    coastline_south_part(i,1)=coastline_south_part(i,1)-(first_id_south-1);   
end
%north part
id_north=coastline_north_part(:,1);
l_north=coastline_north_part(:,2)*(pi/180);%(rads)
f_north=coastline_north_part(:,3)*(pi/180);%(rads)

%south part
id_south=coastline_south_part(:,1);
l_south=coastline_south_part(:,2)*(pi/180);%(rads)
f_south=coastline_south_part(:,3)*(pi/180);%(rads)

%--------------------------------------------------------------------------
%Required inputs for the execution of the source code
%--------------------------------------------------------------------------
spacing=30; %grid spacing in degs (this value corresponds to the grid cell size)
R=6371000; %earth's radius in meters(m)
scale=1; %scale factor to plot x,y
scale_ellipse=0.7*10^6;%scale factor to plot ellipses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% Grid generation according to the predefined spacing value (cell size)
%--------------------------------------------------------------------------
%f:phi (degs)
f=[90:-spacing:-90];
f=f*(pi/180);%phi (rads)
n_f=length(f); %number of grid rows

%l:lamda in degs
l=[-180:spacing:180];
l=l*(pi/180);%lamda in rads
n_l=length(l); %number of grid columns
n=n_f*n_l; %number of grid points
n_grid=n;

%generate the grid
grid=zeros(n_l*n_f,2); %all (f,l) combinations
k=1;%counter
for i=1:n_f
    for j=1:n_l
    grid(k,1)=f(i);
    grid(k,2)=l(j);
    k=k+1;
    end
end
%all phi and lamda values in the generated grid (in rads)
f=grid(:,1);
l=grid(:,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------------------------------------------
%Generate Projections
%--------------------------------------------------------------------------
%mm & mp: principal scale distortions

%--------------------------------------------------------------------------
%Normal Cylindrical Projections
%--------------------------------------------------------------------------
%Normal Equidistant Cylindrical Projection (variable: OKIP)
x=R*l;
y=R*f;
mm=zeros(n,1);
mm(:)=1;
mp=(cos(f)).^(-1);
OKIP=[f*180/pi l*180/pi f l x y mp mm];

%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if OKIP(i,1)~=90 && OKIP(i,1)~=-90
        OKIP_n90(p_n90,:)=OKIP(i,:);
        p_n90=p_n90+1;        
    end
end

figure
axis equal
axis off
ellipse_on_projection(OKIP_n90(:,5),OKIP_n90(:,6),OKIP_n90(:,7),OKIP_n90(:,8),scale,scale_ellipse)
title('Normal Equidistant Cylindrical Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);

x_align=R*l_align;
y_align=R*f_align;

hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);

x_align=R*l_align;
y_align=R*f_align;

hold on
plot(scale*x_align,scale*y_align,'c+')

hold on
x_coastline=R*l_coastline;
y_coastline=R*f_coastline;

plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Equidistant Cylindrical Projection','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);

x_align=R*l_align;
y_align=R*f_align;

hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);

x_align=R*l_align;
y_align=R*f_align;

hold on
plot(x_align,y_align,'c+')

saveas(gcf,'Normal Equidistant Cylindrical Projection_grid_coastline.pdf')


%Mercator Projection (variable: SOKA)
x=R*l;
y=R*log(tan((pi/4)+(f/2)));
mm=(cos(f)).^(-1);
mp=mm;
SOKA=[f*180/pi l*180/pi f l x y mp mm];
%remove records for f=90/-90 (tangent is undefined)
%SOKA_n90
p_n90=1; %pointer
for i=1:n
    if SOKA(i,1)~=90 && SOKA(i,1)~=-90
        SOKA_n90(p_n90,:)=SOKA(i,:);
        p_n90=p_n90+1;       
    end
end

figure
axis equal
axis off
ellipse_on_projection(SOKA_n90(:,5),SOKA_n90(:,6),SOKA_n90(:,7),SOKA_n90(:,8),scale,scale_ellipse)
title('Mercator Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*log(tan((pi/4)+(f_align/2)));

 
hold on
plot(scale*x_align,scale*y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*log(tan((pi/4)+(f_align/2)));

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
x_coastline=R*l_coastline;
y_coastline=R*log(tan((pi/4)+(f_coastline/2)));

plot_coastline([id_coastline x_coastline y_coastline])
title('Mercator Projection','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*log(tan((pi/4)+(f_align/2)));

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*log(tan((pi/4)+(f_align/2)));

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Mercator Projection_grid_coastline.pdf')


%Normal Equivalent Projection (variable: OKIsodP)
x=R*l;
y=R*sin(f);
mm=cos(f);
mp=(cos(f)).^(-1);
OKIsodP=[f*180/pi l*180/pi f l x y mp mm];

%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if OKIsodP(i,1)~=90 && OKIsodP(i,1)~=-90
        OKIsodP_n90(p_n90,:)=OKIsodP(i,:);
        p_n90=p_n90+1;        
    end
end

figure
axis equal
axis off
ellipse_on_projection(OKIsodP_n90(:,5),OKIsodP_n90(:,6),OKIsodP_n90(:,7),OKIsodP_n90(:,8),scale,scale_ellipse)
title('Normal Equivalent Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*sin(f_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*sin(f_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
x_coastline=R*l_coastline;
y_coastline=R*sin(f_coastline);

plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Equivalent Projection','Fontsize',15)
axis equal

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*sin(f_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
 
x_align=R*l_align;
y_align=R*sin(f_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Normal Equivalent Projection_grid_coastline.pdf')

%--------------------------------------------------------------------------
%Normal Conic Projections
%-------------------------------------------------------------------------- 
fo=45; %standard parallel in deg
fo=fo*(pi/180); %standard parallel in rads
xo=(pi/2)-fo; %azimuthal angle of standard parallel in rads
ro=R*tan(xo); %polar radius of standard parallel in m

%Normal Conic Equidistant Projection (variable: OKonIP)
theta=l*cos(xo);
r=ro+R*(fo-f);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=zeros(n,1);
mm(:)=1;
mp=(r.*sin(fo))./(R.*cos(f));
OKonIP=[f*180/pi l*180/pi f l x y mp mm];

%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if OKonIP(i,1)~=90 && OKonIP(i,1)~=-90
        OKonIP_n90(p_n90,:)=OKonIP(i,:);
        p_n90=p_n90+1;        
    end
end

figure
axis equal
axis off
%y-axis rotation
ellipse_on_projection_rotate(OKonIP_n90(:,5),OKonIP_n90(:,6),OKonIP_n90(:,7),OKonIP_n90(:,8),scale,scale_ellipse,OKonIP_n90(:,4)*cos(xo))
title('Normal Conic Equidistant Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=ro+R*(fo-f_align);
x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=ro+R*(fo-f_align);
x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_coastline*cos(xo);
r_coastline=ro+R*(fo-f_coastline);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Conic Equidistant Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=ro+R*(fo-f_align);
x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=ro+R*(fo-f_align);
x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')

saveas(gcf,'Normal Conic Equidistant Projection_grid_coastline.pdf')


%Normal Conformal Conic Projection - Lambert (variable: SKP)
theta=l*cos(xo);
r=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f)/2)).^cos(xo));
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=(r.*sin(fo))./(R.*cos(f));
mp=mm;
SKP=[f*180/pi l*180/pi f l x y mp mm];

%remove records  f=90/-90/0 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if SKP(i,1)~=90 && SKP(i,1)~=-90 
        SKP_n90(p_n90,:)=SKP(i,:);
        p_n90=p_n90+1;        
    end
end


figure
axis equal
axis off
ellipse_on_projection_rotate(SKP_n90(:,5),SKP_n90(:,6),SKP_n90(:,7),SKP_n90(:,8),scale,scale_ellipse,SKP_n90(:,4)*cos(xo))
title('Normal Conformal Conic Projection (Lambert)','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f_align)/2)).^cos(xo));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f_align)/2)).^cos(xo));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_coastline*cos(xo);
r_coastline=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f_coastline)/2)).^cos(xo));
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);
plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Conformal Conic Projection (Lambert)','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f_align)/2)).^cos(xo));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=(R*tan(xo)*((cot(xo/2))^cos(xo)))*((tan(((pi/2)-f_align)/2)).^cos(xo));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Normal Conformal Conic Projection (Lambert)_grid_coastline.pdf')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%Normal Conic Equivalent Projection - Albers (variable: IKP)
theta=l*cos(xo);
r=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f))/(cos(xo)))));
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=(R.*cos(f))./(r.*sin(fo));
mp=1./mm;%(r.*sin(fo))./(R.*cos(f));
IKP=[f*180/pi l*180/pi f l x y mp mm];
%remove records  f=90/-90/0 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if IKP(i,1)~=90 && IKP(i,1)~=-90 
        IKP_n90(p_n90,:)=IKP(i,:);
        p_n90=p_n90+1;        
    end
end

figure
axis equal
axis off
ellipse_on_projection_rotate(IKP_n90(:,5),IKP_n90(:,6),IKP_n90(:,7),IKP_n90(:,8),scale,scale_ellipse,IKP_n90(:,4)*cos(xo))
title('Normal Conic Equivalent Projection - Albers','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f_align))/(cos(xo)))));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a secondcheck point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f_align))/(cos(xo)))));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_coastline*cos(xo);
r_coastline=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f_coastline))/(cos(xo)))));
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);
plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Conic Equivalent Projection - Albers','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f_align))/(cos(xo)))));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


theta_align=l_align*cos(xo);
r_align=sqrt(((R^2)*((tan(xo))^2))+((2*(R^2)).*(1-(cos((pi/2)-f_align))/(cos(xo)))));

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')

saveas(gcf,'Normal Conic Equivalent Projection - Albers_grid_coastline.pdf')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
%Normal Azimuthal Projections
%-------------------------------------------------------------------------- 
chi=(pi/2)-f; %zenithial angle in rad
%M: areal distortion
ro=0;%the cartesian coordinates are centered at north pole
%Normal Azimuthal Equidistant Projection - Postel (variable: OEIP)
theta=l;
r=R*((pi/2)-f);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=zeros(n,1);
mm(:)=1;
mp=((pi/2)-f)./(sin((pi/2)-f));
OEIP=[f*180/pi l*180/pi f l x y mp mm];

%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if OEIP(i,1)~=90 && OEIP(i,1)~=-90
        OEIP_n90(p_n90,:)=OEIP(i,:);
        p_n90=p_n90+1;      
    end
end

figure
axis equal
axis off
ellipse_on_projection_rotate(OEIP_n90(:,5),OEIP_n90(:,6),OEIP_n90(:,7),OEIP_n90(:,8),scale,scale_ellipse,OEIP_n90(:,4))
title('Normal Azimuthal Equidistant Projection (Postel)','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*((pi/2)-f_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*((pi/2)-f_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
chi_coastline=(pi/2)-f_coastline; %zenithial angle in rad
%M: areal distortion
ro=0;%the cartesian coordinates are centered at north pole
%Normal Azimuthal Equidistant Projection - Postel (variable: OEIP)
theta_coastline=l_coastline;
r_coastline=R*((pi/2)-f_coastline);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_coastline x_coastline y_coastline])
title('Normal Azimuthal Equidistant Projection (Postel)','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*((pi/2)-f_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*((pi/2)-f_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Normal Azimuthal Equidistant Projection (Postel)_grid_coastline.pdf')


%Polar Stereographic Projection (variable: PSP)
theta=l;
r=2*R*tan(chi/2);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=1./((cos(chi/2)).^2);
mp=mm;
M=1./((cos(chi/2)).^4);
PSP=[f*180/pi l*180/pi f l x y mp mm M];


%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if PSP(i,1)~=90 && PSP(i,1)~=-90
        PSP_n90(p_n90,:)=PSP(i,:);
        p_n90=p_n90+1;        
    end
end

figure
axis equal
axis off
ellipse_on_projection_rotate(PSP_n90(:,5),PSP_n90(:,6),PSP_n90(:,7),PSP_n90(:,8),scale,scale_ellipse,PSP_n90(:,4))
title('Polar Stereographic Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*tan(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);
 
hold on
plot(scale*x_align,scale*y_align,'g+')
%Define a check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*tan(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);
 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_coastline;
r_coastline=2*R*tan(chi_coastline/2);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_coastline x_coastline y_coastline])
title('Polar Stereographic Projection','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*tan(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);
 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*tan(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);
 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Polar Stereographic Projection_grid_coastline.pdf')


%Polar Equivalent Projection - Lambert (variable: PEIP)
theta=l;
r=2*R*sin(chi/2);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=cos(chi/2);
mp=1./mm;
M=zeros(n,1);
M(:)=1;
PEIP=[f*180/pi l*180/pi f l x y mp mm M];

%remove records  f=90/-90 (mp is undefined)
p_n90=1; %pointer
for i=1:n
    if PEIP(i,1)~=90 && PEIP(i,1)~=-90
        PEIP_n90(p_n90,:)=PEIP(i,:);
        p_n90=p_n90+1;        
    end
end


figure
axis equal
axis off
ellipse_on_projection_rotate(PEIP_n90(:,5),PEIP_n90(:,6),PEIP_n90(:,7),PEIP_n90(:,8),scale,scale_ellipse,PEIP_n90(:,4))
title('Polar Equivalent Projection (Lambert)','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*sin(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*sin(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_coastline;
r_coastline=2*R*sin(chi_coastline/2);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_coastline x_coastline y_coastline])
title('Polar Equivalent Projection (Lambert)','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*sin(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=2*R*sin(chi_align/2);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Polar Equivalent Projection (Lambert)_grid_coastline.pdf')

%Polar Gnomonic Projection (variable: PGP)
theta=l;
r=R*tan(chi);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=1./((cos(chi)).^2);
mp=1./cos(chi);
M=1./((cos(chi)).^3);
PGP=[f*180/pi l*180/pi f l x y mp mm M];

%remove records  f=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n
    if PGP(i,1)~=0 
        PGP_n0(p_n0,:)=PGP(i,:);
        p_n0=p_n0+1;        
    end
end

figure
axis equal
axis off
ellipse_on_projection_rotate(PGP_n0(:,5),PGP_n0(:,6),PGP_n0(:,7),PGP_n0(:,8),scale,scale_ellipse,PGP_n0(:,4))
title('Polar Gnomonic Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*tan(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*tan(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
theta_coastline=l_north;
r_coastline=R*tan((pi/2)-f_north);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_north x_coastline y_coastline])
title('Polar Gnomonic Projection','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*tan(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*tan(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Polar Gnomonic Projection_grid_coastline.pdf')

%Polar Orthographic Projection (variable: POP)
theta=l;
r=R*sin(chi);
x=r.*sin(theta);
y=ro-r.*cos(theta);
mm=cos(chi);
mp=zeros(n,1);
mp(:)=1;
M=cos(chi);

POP=[f*180/pi l*180/pi f l x y mp mm M];

figure
axis equal
axis off
ellipse_on_projection_rotate(x,y,mp,mm,scale,scale_ellipse,l)
title('Polar Orthographic Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*sin(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*sin(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(scale*x_align,scale*y_align,'c+')
hold on
%Seperate north and south part of the coastline (in the computations made above the north part was considered after 20 degrees, here the north part is seperated
%from south part from equator)
n=size(id_coastline);
n=n(1,1);
coastline_north_part=[];
coastline_south_part=[];
for i=1:n
    if f_coastline(i)>0 || f_coastline(i)==0 
        coastline_north_part=[coastline_north_part; coastline(i,:)];
    else
        coastline_south_part=[coastline_south_part; coastline(i,:)];
    end
end
%number of point in north part
n_north=size(coastline_north_part);
n_north=n_north(1,1);
%number of point in south part
n_south=size(coastline_south_part);
n_south=n_south(1,1);
first_id_north=coastline_north_part(1,1); %IDs must be started from number one in order to use plot_coastline function
first_id_south=coastline_south_part(1,1); %IDs must be started from number one in order to use plot_coastline function

if first_id_north>1    
    for i=1:n_north
        coastline_north_part(i,1)=coastline_north_part(i,1)-(first_id_north-1);
    end
else
    coastline_south_part(i,1)=coastline_south_part(i,1)-(first_id_south-1);   
end
%north part
id_north=coastline_north_part(:,1);
l_north=coastline_north_part(:,2)*(pi/180);%(rads)
f_north=coastline_north_part(:,3)*(pi/180);%(rads)

%south part
id_south=coastline_south_part(:,1);
l_south=coastline_south_part(:,2)*(pi/180);%(rads)
f_south=coastline_south_part(:,3)*(pi/180);%(rads)


theta_coastline=l_north;
r_coastline=R*sin((pi/2)-f_north);
x_coastline=r_coastline.*sin(theta_coastline);
y_coastline=ro-r_coastline.*cos(theta_coastline);

plot_coastline([id_north x_coastline y_coastline])
title('Polar Orthographic Projection','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*sin(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);
chi_align=(pi/2)-f_align;

theta_align=l_align;
r_align=R*sin(chi_align);

x_align=r_align.*sin(theta_align);
y_align=ro-r_align.*cos(theta_align);

 
hold on
plot(x_align,y_align,'c+')
saveas(gcf,'Polar Orthographic Projection_grid_coastline.pdf')





%%%%%%Coastline must be imported

%--------------------------------------------------------------------------
%Transverse Projections
%--------------------------------------------------------------------------
%f,l to u,v
u=atan(1./(cot(f).*cos(l)));
v=asin(cos(f).*sin(l));

%Transverse Cylindrical Equidistant Projection - Cassini (variable: EIP)
x=R*v;
y=R*u;
mm=1./cos(v);
mp=zeros(n_grid,1);
mp(:)=1;
EIP=[f*180/pi l*180/pi f l x y u v mp mm];

%remove records  v=0 (mp is undefined)
p_n0=1; %pointer
for i=1:n_grid
    if EIP(i,8)~=0 
        EIP_n0(p_n0,:)=EIP(i,:);
        p_n0=p_n0+1;        
    end
end

figure 
plot(x,y,'k.')
axis equal
axis off
title('Transverse Cylindrical Equidistant Projection (Cassini) ','Fontsize',15)
%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


u_align=atan(1./(cot(f_align).*cos(l_align)));
v_align=asin(cos(f_align).*sin(l_align));

x_align=R*v_align;
y_align=R*u_align;

 
hold on
plot(scale*x_align,scale*y_align,'g+')

%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


u_align=atan(1./(cot(f_align).*cos(l_align)));
v_align=asin(cos(f_align).*sin(l_align));

x_align=R*v_align;
y_align=R*u_align;

 
hold on
plot(scale*x_align,scale*y_align,'c+')
saveas(gcf,'Transverse Cylindrical Equidistant Projection (Cassini)_grid.pdf')

%Transverse Mercator Projection (variable: EMP)
x=R*log(tan((pi/4)+(v/2)));
y=R*u;
mm=1./cos(v);
mp=mm;
EMP=[f*180/pi l*180/pi f l x y u v mp mm];
%remove records  v=90 (x is undefined)
p_n90=1; %pointer
for i=1:n_grid
    if EMP(i,8)~=pi/2 && EMP(i,8)~=-pi/2 
        EMP_n90(p_n90,:)=EMP(i,:);
        p_n90=p_n90+1;        
    end
end
figure 
plot(EMP_n90(:,5),EMP_n90(:,6),'k.')
axis equal
axis off
% figure
% ellipse_on_projection(x,y,mm,mp,scale)
title('Transverse Mercator Projection','Fontsize',15)

%Define a check point f_align,l_align
f_align=30;
f_align=f_align*(pi/180);
l_align=30;
l_align=l_align*(pi/180);


u_align=atan(1./(cot(f_align).*cos(l_align)));
v_align=asin(cos(f_align).*sin(l_align));

x_align=R*log(tan((pi/4)+(v_align/2)));
y_align=R*u_align;

 
hold on
plot(scale*x_align,scale*y_align,'g+')
%Define a second check point f_align,l_align
f_align=40;
f_align=f_align*(pi/180);
l_align=40;
l_align=l_align*(pi/180);


u_align=atan(1./(cot(f_align).*cos(l_align)));
v_align=asin(cos(f_align).*sin(l_align));

x_align=R*log(tan((pi/4)+(v_align/2)));
y_align=R*u_align;

 
hold on
plot(scale*x_align,scale*y_align,'c+')
saveas(gcf,'Transverse Mercator Projection_grid.pdf')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('End of results\n\n\n\n\n')

fprintf('\n GenCartoPro: GENeration of CARTOgraphic PROjections \n')
fprintf(' 2016 Vassilios Krassanakis, Vassilios Mitropoulos, Byron Nakos (National Technical University of Athens), Kallipos Project: Analytical Cartography \n')
fprintf('\n')
fprintf(' This program is free software: you can redistribute it and/or modify\n')
fprintf(' it under the terms of the GNU General Public License as published by\n')
fprintf(' the Free Software Foundation, either version 3 of the License, or\n')
fprintf(' (at your option) any later version.\n')
fprintf('\n')
fprintf(' This program is distributed in the hope that it will be useful,\n')
fprintf(' but WITHOUT ANY WARRANTY; without even the implied warranty of\n')
fprintf(' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n')
fprintf(' GNU General Public License for more details.\n')
fprintf('\n')
fprintf(' You should have received a copy of the GNU General Public License\n')
fprintf(' along with this program.  If not, see <http://www.gnu.org/licenses/>.\n')
fprintf('\n')
fprintf(' For further information, please send an email to: krasanakisv@gmail.com or krasvas@mail.ntua.gr\n')
